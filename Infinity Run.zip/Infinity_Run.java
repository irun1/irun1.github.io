import java.awt.Toolkit;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.Font;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.BasicStroke;
import java.awt.event.ActionListener;
import java.awt.event.FocusListener;
import java.awt.image.BufferedImage;
import java.awt.event.KeyEvent;
import java.awt.event.ActionEvent;
import java.awt.event.FocusEvent;
import java.awt.event.KeyListener;
import java.awt.event.ComponentListener;
import java.awt.event.ComponentEvent;
import javax.swing.JPanel;
import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.ImageIcon;
import javax.swing.BorderFactory;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JTextArea;
import javax.swing.JToggleButton;
import javax.swing.Timer;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.sound.sampled.Clip;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.imageio.ImageIO;
import java.io.File;
import java.io.FileWriter;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.BufferedReader;
import javax.swing.Icon;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.Image;
import java.awt.event.MouseListener;
import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;
class Infinity_Run extends JPanel implements ActionListener, FocusListener, KeyListener
{
    int currentPage, x, y, image;
    String location;
    JFrame sets;
    JPanel bg, panel;
    JButton start, user, previous, next, board;
    JTextField name;
    JTextArea leaders;
    File images[];
    backend object;
    @Override
    public void keyReleased(KeyEvent e)
    {
    }

    @Override
    public void keyPressed(KeyEvent e)
    {
        if(e.getKeyCode()==KeyEvent.VK_ENTER)
            start.doClick();
    }

    @Override
    public void keyTyped(KeyEvent e)
    {
    }

    void main()
    {
        String player, names[]=null;
        sets=new JFrame("Infinity Run - Home");
        sets.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        sets.setIconImage(Toolkit.getDefaultToolkit().getImage("Logo.jpg"));
        sets.setLayout(null);
        sets.setExtendedState(JFrame.MAXIMIZED_BOTH);
        sets.setResizable(false);
        sets.setVisible(true);
        try
        {
            UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
        }
        catch(Exception e)
        {
        }
        name=new JTextField("Enter your name");
        name.addFocusListener(this);
        name.addKeyListener(this);
        board=new JButton("LEADERBOARD");
        board.setFont(new Font("Comic Sans MS", Font.PLAIN, 14));
        board.setBounds(sets.getWidth()-300, 10, 160, 40);
        board.setToolTipText("Leaderboard");
        board.addActionListener(this);
        board.setVisible(true);
        leaders=new JTextArea("");
        leaders.setToolTipText("Leaders");
        leaders.setFont(new Font("ARIAL", Font.PLAIN, 17));
        leaders.setBackground(new Color(160, 160, 160, 100));
        leaders.setBounds(sets.getWidth()-300, 60, 255, 250);
        leaders.setBorder(BorderFactory.createEmptyBorder());
        leaders.setVisible(false);
        leaders.setForeground(Color.PINK);
        leaders.setFocusable(false);
        user=new JButton(new ImageIcon("User.jpg"));
        user.setBounds((sets.getWidth()-130)/2, (sets.getHeight()-130)/4, 130, 130);
        user.setBorder(BorderFactory.createEmptyBorder());
        user.addActionListener(this);
        user.setToolTipText("Profile photo");
        try
        {
            object=new backend("", "User.jpg", user.getIcon());
            location=object.read()[0].split(";")[1];
        }
        catch(Exception e)
        {
        }
        start=new JButton("START");
        start.setFont(new Font("Comic Sans MS", Font.PLAIN, 14));
        start.setBounds((sets.getWidth()-90)/2, (sets.getHeight()-150), 90, 40);
        image=(int)(11*Math.random()+1);
        bg=new JPanel()
        {
            @Override
            protected void paintComponent(Graphics g)
            {
                super.paintComponent(g);
                try
                {
                    BufferedImage img=ImageIO.read(new File("Background (" + image + ").jpeg"));
                    g.drawImage(img, 0, 0, getWidth(), getHeight(), this);
                    g.setColor(new Color(255, 0, 0));
                    g.setFont(new Font("Arial", Font.BOLD, 14));
                    g.drawString("ASHIRVAAD VERMA", 12, 24);
                }
                catch(Exception e)
                {
                }
            }
        };
        bg.setLayout(null);
        bg.add(user);
        bg.add(board);
        bg.add(leaders);
        panel=new JPanel(new GridLayout(3, 3));
        panel.setOpaque(false);
        panel.setBounds(75, 150, 300, 300);
        panel.setVisible(false);
        bg.add(panel);
        previous=new JButton("PREVIOUS");
        previous.setFocusable(false);
        previous.setToolTipText("Previous tray");
        previous.setBounds(75, 500, 101, 40);
        previous.setFont(new Font("Comic Sans MS", Font.PLAIN, 14));
        previous.setVisible(false);
        previous.addActionListener(this);
        bg.add(previous);
        next=new JButton("NEXT");
        next.setFont(new Font("Comic Sans MS", Font.PLAIN, 14));
        next.setFocusable(true);
        next.setBounds(274, 500, 101, 40);
        next.setVisible(false);
        next.addActionListener(this);
        next.setToolTipText("Next tray");
        bg.add(next);
        name.setBounds((sets.getWidth()-300)/2, (sets.getHeight()-40)/2, 300, 40);
        name.setToolTipText(name.getText());
        name.setFont(new Font("Comic Sans MS", Font.BOLD, 20));
        try
        {
            name.setText(object.read()[0].split(";")[0]);
            user.setIcon(object.resize(130, new File(object.read()[0].split(";")[1])));
        }
        catch(Exception e)
        {
        }
        bg.add(name);
        start.setToolTipText("Start game");
        bg.add(start);
        start.addActionListener(this);
        try
        {
            names=object.read();
        }
        catch(Exception e)
        {
        }
        for(int i=0, j, temp; i<10 && i<names.length; i++)
        {
            for(j=i, temp=i; j<names.length; j++)
                if(Integer.valueOf(names[temp].split(";")[2])<Integer.valueOf(names[j].split(";")[2]))
                    temp=j;
            player=names[i];
            names[i]=names[temp];
            names[temp]=player;
        }
        for(int i=0; i<10 && i<names.length; i++)
            leaders.setText(leaders.getText() + "\n  " + (i+1) + "\t" + names[i].split(";")[0] + "\t" + names[i].split(";")[2]);
        try
        {
            object.notif((sets.getWidth()-453)/2, (sets.getHeight()-30)/2+75, 453, 30, -1, "You can change the name and photo by clicking on them", Color.RED, bg);
        }
        catch(Exception e)
        {
        }
        sets.setContentPane(bg);
        sets.revalidate();
        sets.repaint();
    }

    int check()
    {
        String player=name.getText();
        if(player.length()>10)
            return 1;
        for(int i=0; i<player.length(); i++)
            if(Character.isLetter(player.charAt(i))==false)
                return 2;
        return 3;
    }

    @Override
    public void actionPerformed(ActionEvent e)
    {
        if(e.getSource()==start)
            try
            {
                if(check()==3)
                {
                    sets.setVisible(false);
                    object.startGame(0, name.getText(), location, user.getIcon());
                }
            }
            catch(Exception error)
            {
            }
        else if(e.getSource()==user)
        {
            JFileChooser directory=new JFileChooser();
            directory.setCurrentDirectory(new File("Avatars"));
            directory.setApproveButtonText("Select");
            directory.setDialogTitle("Choose your profile picture");
            directory.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
            if(directory.showOpenDialog(null)==JFileChooser.APPROVE_OPTION)
            {
                File files[]=directory.getSelectedFile().listFiles();
                images=filter(files);
                currentPage=0;
                display(currentPage);
            }
        }
        else if(e.getSource()==next && (currentPage+1)*9<images.length)
            display(++currentPage);
        else if(e.getSource()==previous && currentPage>0)
            display(--currentPage);
        else if(e.getSource()==board)
            if(leaders.isVisible())
                leaders.setVisible(false);
            else
                leaders.setVisible(true);
    }

    @Override
    public void focusGained(FocusEvent e)
    {
        if(e.getSource()==name)
        {
            name.setText("");
            name.setForeground(Color.BLACK);
        }
    }

    @Override
    public void focusLost(FocusEvent e)
    {
        if(check()==1 || check()==2)
            name.setForeground(Color.RED);
        if(check()==1)
            name.setText("Maximum letter limit is 10");
        else if(check()==2)
            name.setText("Only letters are allowed");
    }

    File[] filter(File files[])
    {
        int count=0;
        if(files==null)
            return new File[0];
        for(int i=0; i<files.length; i++)
        {
            String filename=files[i].getName().toLowerCase();
            if(filename.endsWith(".jpg") || filename.endsWith(".png") || filename.endsWith(".gif") || filename.endsWith(".bmp") || filename.endsWith(".jpeg"))
                count++;
        }
        File images[]=new File[count];
        for(int i=0, index=0; i<files.length; i++)
        {
            String filename=files[i].getName().toLowerCase();
            if(filename.endsWith(".jpg") || filename.endsWith(".png") || filename.endsWith(".gif") || filename.endsWith(".bmp") || filename.endsWith(".jpeg"))
                images[index++]=files[i];
        }
        return images;
    }

    void display(int page)
    {
        int start=page*9, end=Math.min(start+9, images.length);
        panel.removeAll();
        for(int i=start; i<end; i++)
            try
            {
                panel.setVisible(true);
                JLabel imageLabel=new JLabel();
                imageLabel.setIcon(object.resize(100, images[i]));
                panel.add(imageLabel);
                final BufferedImage finalImg=ImageIO.read(images[i]);
                final int index=i;
                imageLabel.addMouseListener(new MouseAdapter()
                    {
                        @Override
                        public void mouseClicked(MouseEvent e)
                        {
                            Image scaledImage=finalImg.getScaledInstance(user.getWidth(), user.getHeight(), Image.SCALE_SMOOTH);
                            user.setIcon(new ImageIcon(scaledImage));
                            panel.setVisible(false);
                            previous.setVisible(false);
                            next.setVisible(false);
                            location=images[index].getPath();
                        }
                    });
            }
            catch(Exception error)
            {
            }
        next.setVisible(end<images.length);
        previous.setVisible(start>0);
        sets.revalidate();
        sets.repaint();
    }
}
class backend extends JPanel implements ActionListener, KeyListener, ComponentListener, MouseListener
{
    int pos[]=new int[3];
    int loop1, x1, check1, x2[]=new int[2], y1[]=new int[2], x3[]=new int[11], check2, y2[]=new int[11], points, moves=15, height=420, width=420, x, y, check3, check4, y3[]=new int[4], check5, check6;
    String location;
    JTextField notification;
    JTextArea score, opponent;
    JFrame set;
    JButton play, pause, settings, photo, restart, target;
    JToggleButton state;
    JRadioButton dynamic, light, dark, oval, rect, rrect;
    ButtonGroup theme, style;
    JLabel character, memoji;
    Clip clip;
    Timer timer;
    backend(String name, String location, Icon img) throws Exception
    {
        timer=new Timer(16, this);
        timer.start();
        setFocusable(true);
        addKeyListener(this);
        addMouseListener(this);
        y1[1]=(int)(101*Math.random()-250);
        if(read()[0].split(";")[0].equals(name))
            score=new JTextArea(name + "\nHighscore: " + read()[0].split(";")[2] + "\nScore: " + points);
        else
            score=new JTextArea(name + "\nHighscore: 0\nScore: " + points);
        score.setToolTipText("Scoreboard");
        score.setFocusable(false);
        score.setFont(new Font("Kristen ITC", Font.BOLD, 17));
        score.setBackground(new Color(255, 255, 255, 0));
        score.setBorder(BorderFactory.createEmptyBorder());
        play=new JButton(new ImageIcon("Resume.jpeg"));
        play.setToolTipText("Resume game");
        play.setMnemonic(KeyEvent.VK_P);
        pause=new JButton(new ImageIcon("Pause.jpeg"));
        pause.setToolTipText("Pause game");
        pause.setMnemonic(KeyEvent.VK_S);
        settings=new JButton(new ImageIcon("Settings.jpeg"));
        settings.setToolTipText("Open settings");
        settings.setMnemonic(KeyEvent.VK_C);
        character=new JLabel(new ImageIcon("Dead.png"));
        play.setBounds(5, 5, 50, 50);
        pause.setBounds(5, 5, 50, 50);
        settings.setBounds(55, 5, 50, 50);
        pause.addActionListener(this);
        play.addActionListener(this);
        settings.addActionListener(this);
        addComponentListener(this);
        this.setLayout(null);
        this.add(score);
        this.add(pause);
        this.add(settings);
        this.add(character);
        set=new JFrame("Infinity Run - Settings");
        set.setLayout(null);
        set.setIconImage(Toolkit.getDefaultToolkit().getImage("Settings.jpg"));
        set.setSize(420, 420);
        dynamic=new JRadioButton("Dynamic", true);
        light=new JRadioButton("Light");
        dark=new JRadioButton("Dark");
        oval=new JRadioButton("Oval", true);
        rect=new JRadioButton("Square");
        rrect=new JRadioButton("Squicircle");
        dynamic.addActionListener(this);
        light.addActionListener(this);
        dark.addActionListener(this);
        oval.addActionListener(this);
        rect.addActionListener(this);
        rrect.addActionListener(this);
        dynamic.setBounds(30, 82, 100, 30);
        light.setBounds(160, 82, 100, 30);
        dark.setBounds(290, 82, 100, 30);
        theme=new ButtonGroup();
        theme.add(dynamic);
        theme.add(light);
        theme.add(dark);
        style=new ButtonGroup();
        style.add(oval);
        style.add(rect);
        style.add(rrect);
        set.add(dynamic);
        set.add(light);
        set.add(dark);
        set.add(oval);
        set.add(rect);
        set.add(rrect);
        oval.setBounds(30, 194, 100, 30);
        rect.setBounds(160, 194, 100, 30);
        rrect.setBounds(290, 194, 100, 30);
        dynamic.setVisible(true);
        light.setVisible(true);
        dark.setVisible(true);
        oval.setVisible(true);
        rect.setVisible(true);
        rrect.setVisible(true);
        state=new JToggleButton("Sound ON");
        state.setBounds(160, 306, 100, 30);
        set.add(state);
        state.addActionListener(this);
        photo=new JButton();
        photo.setIcon(img);
        photo.setBackground(new Color(255, 255, 255, 0));
        photo.setBorder(BorderFactory.createEmptyBorder());
        add(photo);
        memoji=new JLabel();
        if(score.getText().split("\n")[0].endsWith("a") || score.getText().split("\n")[0].endsWith("e") || score.getText().split("\n")[0].endsWith("i") || score.getText().split("\n")[0].endsWith("m") || score.getText().split("\n")[0].endsWith("o") || score.getText().split("\n")[0].endsWith("u"))
            memoji.setIcon(resize(100, new File("Victory (1).png")));
        else
            memoji.setIcon(resize(100, new File("Victory (2).png")));
        memoji.setBorder(BorderFactory.createEmptyBorder());
        memoji.setOpaque(false);
        add(memoji);
        restart=new JButton("RESTART");
        restart.setFont(new Font("Comic Sans MS", Font.BOLD, 14));
        add(restart);
        restart.setVisible(false);
        restart.setToolTipText("Restart game");
        restart.addActionListener(this);
        restart.addKeyListener(this);
        opponent=new JTextArea(find(points).split(";")[0].equals(score.getText().split("\n")[0])?"You" + "\nHighscore: " + find(points).split(";")[2]:find(points).split(";")[0] + "\nHighscore: " + find(points).split(";")[2]);
        opponent.setBackground(new Color(255, 255, 255, 0));
        opponent.setFocusable(false);
        opponent.setFont(new Font("Kristen ITC", Font.BOLD, 17));
        opponent.setToolTipText("Target");
        opponent.setBorder(BorderFactory.createEmptyBorder());
        add(opponent);
        this.location=location;
        target=new JButton();
        target.setIcon(resize(75, new File(find(0).split(";")[1])));
        target.setBackground(new Color(255, 255, 255, 0));
        target.setBorder(BorderFactory.createEmptyBorder());
        add(target);
        notification=new JTextField();
        notification.setHorizontalAlignment(JTextField.CENTER);
        notification.setBorder(BorderFactory.createEmptyBorder());
        notification.setFont(new Font("Bahnschrift", Font.BOLD, 17));
        notification.setOpaque(false);
        notification.setVisible(true);
    }

    @Override
    protected void paintComponent(Graphics g)
    {
        super.paintComponent(g);
        Graphics2D g2d=(Graphics2D)g;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2d.setStroke(new BasicStroke(5));
        g.setColor(new Color(42, 48, 43));
        g2d.drawLine(x, 0, 10, height);
        g2d.drawLine(x+70, 0, y+20, height);
        g2d.drawLine(x*3+80, 0, y+40, height);
        g2d.drawLine(x*3+150, 0, y*2+50, height);
        g2d.drawLine(x*5+160, 0, y*2+70, height);
        g2d.drawLine(x*5+230, 0, y*3+80, height);
        if(getBackground().equals(new Color(235, 228, 228)))
            g.setColor(new Color(255, 255, 255));
        else
            g.setColor(new Color(130, 125, 120));
        for(loop1=0; loop1<4; loop1++)
        {
            g.fillRect(pos[0]+17, y3[loop1], 15, height/7);
            g.fillRect(pos[1]+17, y3[loop1], 15, height/7);
            g.fillRect(pos[2]+17, y3[loop1], 15, height/7);
        }
        g.setColor(new Color(250, 213, 5));
        for(loop1=0; loop1<5; loop1++)
            if(check6==0)
                g.fillOval(x3[loop1]+12, y2[loop1], 25, 25);
            else if(check6==1)
                g.fillRect(x3[loop1]+12, y2[loop1], 25, 25);
            else if(check6==2)
                g.fillRoundRect(x3[loop1]+12, y2[loop1], 25, 25, 15, 15);
        g.setColor(new Color(255, 128, 0));
        for(; loop1<10; loop1++)
            if(check6==0)
                g.fillOval(x3[loop1]+12, y2[loop1], 25, 25);
            else if(check6==1)
                g.fillRect(x3[loop1]+12, y2[loop1], 25, 25);
            else if(check6==2)
                g.fillRoundRect(x3[loop1]+12, y2[loop1], 25, 25, 15, 15);
        g.setColor(Color.BLUE);
        g.fillOval(x3[10]+12, y2[10], 25, 25);
        g.setColor(Color.RED);
        g.fillRect(x2[0], y1[0], 50, 50);
        for(; x2[0]==x2[1] && y1[0]==y1[1]; )
            x2[1]=x2[0]=pos[(int)(3*Math.random())];
        g.fillRect(x2[1], y1[1], 50, 50);
    }

    @Override
    public void componentResized(ComponentEvent e)
    {
        height=getHeight();
        width=getWidth();
        x=(width-240)/6;
        y=(width-100)/3;
        pos[0]=x+15;
        pos[1]=pos[0]+80+x*2;
        pos[2]=2*pos[1]-pos[0];
        x1=pos[1];
        for(loop1=0; loop1<2; loop1++)
            x2[loop1]=pos[(int)(3*Math.random())];
        for(loop1=0; loop1<11; loop1++)
            x3[loop1]=pos[(int)(3*Math.random())];
        y3[0]=0;
        y3[1]=2*height/7;
        y3[2]=4*height/7;
        y3[3]=6*height/7;
        repaint();
        score.setBounds(width-180, 85, 175, 70);
        restart.setBounds((width-101)/2, (height-40)/4, 101, 40);
        photo.setBounds(score.getX()+(width-score.getX()-75)/2, 5, 75, 75);
        target.setBounds(score.getX()+(width-score.getX()-75)/2, score.getY()+83, 75, 75);
        opponent.setBounds(width-180, score.getY()+185, 175, 44);
        memoji.setBounds(score.getX()+(width-score.getX()-100)/2, score.getY()+83, 100, 100);
        memoji.setVisible(false);
        if(points==0)
        {
            pause.doClick();
            try
            {
                notif((width-210)/2, (height-210)/4, 210, 25, 3000, "3", Color.RED, null);
            }
            catch(Exception a)
            {
            }
            Timer countdown2=new Timer(1000, new ActionListener()
                    {
                        @Override
                        public void actionPerformed(ActionEvent e)
                        {
                            try
                            {
                                notif((width-210)/2, (height-210)/4, 210, 25, 3000, "2", Color.ORANGE, null);
                            }
                            catch(Exception b)
                            {
                            }
                        }
                    });
            countdown2.setRepeats(false);
            countdown2.start();
            Timer countdown1=new Timer(2000, new ActionListener()
                    {
                        @Override
                        public void actionPerformed(ActionEvent e)
                        {
                            try
                            {
                                notif((width-210)/2, (height-210)/4, 210, 25, 3000, "1", Color.YELLOW, null);
                            }
                            catch (Exception b)
                            {
                            }
                        }
                    });
            countdown1.setRepeats(false);
            countdown1.start();
            Timer countdown0=new Timer(3000, new ActionListener()
                    {
                        @Override
                        public void actionPerformed(ActionEvent e)
                        {
                            try
                            {
                                notif((width-210)/2, (height-210)/4, 210, 25, 1500, "RUN!", Color.GREEN, null);
                                play.doClick();
                            }
                            catch(Exception b)
                            {
                            }
                        }
                    });
            countdown0.setRepeats(false);
            countdown0.start();
        }
    }

    @Override
    public void componentHidden(ComponentEvent e)
    {
    }

    @Override
    public void componentShown(ComponentEvent e)
    {
    }

    @Override
    public void componentMoved(ComponentEvent e)
    {
    }

    @Override
    public void mouseExited(MouseEvent e)
    {
    }

    @Override
    public void mouseEntered(MouseEvent e)
    {
    }

    @Override
    public void mouseReleased(MouseEvent e)
    {
    }

    @Override
    public void mousePressed(MouseEvent e)
    {
        if(e.getButton()==MouseEvent.BUTTON1 && (check1==0 || check1==1))
        {
            x1-=(pos[1]-pos[0]);
            check1--;
        }
        else if(e.getButton()==MouseEvent.BUTTON3 && (check1==-1 || check1==0))
        {
            x1+=(pos[1]-pos[0]);
            check1++;
        }
    }

    @Override
    public void mouseClicked(MouseEvent e)
    {
    }

    @Override
    public void actionPerformed(ActionEvent e)
    {
        for(loop1=0; loop1<2; loop1++)
            y1[loop1]+=moves;
        for(loop1=0; loop1<11; loop1++)
            y2[loop1]+=moves;
        for(loop1=0; loop1<4; loop1++)
            y3[loop1]+=moves;
        try
        {
            if(y2[10]<-9000 && y2[10]>=-10000 && check3==1 && notification.getText().equals("Special ability activated (5)")==false)
                notif((width-210)/2, (height-210)/4, 220, 25, -1, "Special ability activated (5)", new Color(0, 255, 0), null);
            else if(y2[10]<-8000 && y2[10]>=-9000 && check3==1 && notification.getText().equals("Special ability activated (4)")==false)
                notif((width-210)/2, (height-210)/4, 220, 25, -1, "Special ability activated (4)", new Color(255, 255, 0), null);
            else if(y2[10]<-7000 && y2[10]>=-8000 && check3==1 && notification.getText().equals("Special ability activated (3)")==false)
                notif((width-210)/2, (height-210)/4, 220, 25, -1, "Special ability activated (3)", new Color(255, 153, 0), null);
            else if(y2[10]<-6000 && y2[10]>=-7000 && check3==1 && notification.getText().equals("Special ability activated (2)")==false)
                notif((width-210)/2, (height-210)/4, 220, 25, -1, "Special ability activated (2)", new Color(255, 51, 0), null);
            else if(y2[10]<-5000 && y2[10]>=-6000 && check3==1 && notification.getText().equals("Special ability activated (1)")==false)
                notif((width-210)/2, (height-210)/4, 220, 25, -1, "Special ability activated (1)", new Color(204, 0, 0), null);
        }
        catch(Exception b)
        {
        }
        character.setBounds(x1-21, height-150, 91, 150);
        if(y1[0]>height)
        {
            y1[0]=-50;
            x2[0]=pos[(int)(3*Math.random())];
        }
        else if(y1[1]>height)
        {
            y1[1]=(int)(101*Math.random()-250);
            x2[1]=pos[(int)(3*Math.random())];
        }
        for(loop1=0; loop1<10; loop1++)
            if(y2[loop1]>height)
            {
                y2[loop1]=-50;
                x3[loop1]=pos[(int)(3*Math.random())];
            }
        if(y2[10]>height)
        {
            y2[10]=-10000;
            x3[10]=pos[(int)(3*Math.random())];
        }
        for(loop1=0; loop1<4; loop1++)
            if(y3[loop1]>height)
                y3[loop1]=-height/7;
        if(y2[10]>-5000 && check3==1)
        {
            check3=0;
            try
            {
                notif((width-210)/2, (height-210)/4, 220, 25, 3000, "Special ability deactivated", Color.RED, null);
            }
            catch(Exception b)
            {
            }
        }
        if(((x1==x2[0] && y1[0]>=(height-200)) || (x1==x2[1] && y1[1]>=(height-200))) && (check3==0 || y2[10]>-7000))
        {
            check2=1;
            timer.stop();
            play.setEnabled(false);
            pause.setEnabled(false);
            settings.setEnabled(false);
            try
            {
                play("End.wav");
                notif((width-210)/2, (height-210)/4, 210, 25, -1, "GAME OVER", Color.RED, null);
                character.setIcon(new ImageIcon("Dead.png"));
                if(score.getText().split("\n")[0].endsWith("a") || score.getText().split("\n")[0].endsWith("e") || score.getText().split("\n")[0].endsWith("i") || score.getText().split("\n")[0].endsWith("m") || score.getText().split("\n")[0].endsWith("o") || score.getText().split("\n")[0].endsWith("u"))
                    memoji.setIcon(resize(100, new File("Shocked (1).png")));
                else
                    memoji.setIcon(resize(100, new File("Shocked (2).png")));
                opponent.setVisible(false);
                target.setVisible(false);
                memoji.setVisible(true);
                restart.setVisible(true);
                int i=0, check=0;
                for(; i<read().length; i++)
                    if(readLine(i).split(";")[0].equals(score.getText().split("\n")[0]))
                    {
                        if(Integer.valueOf(readLine(i).split(";")[2])<points)
                            writeOnLine(i, 1, score.getText().split("\n")[0]+";"+location+";"+points+";"+check4);
                        else
                            writeOnLine(i, 1, score.getText().split("\n")[0]+";"+location+";"+readLine(i).split(";")[2]+";"+check4);
                        check=1;
                    }
                if(check==0)
                    writeOnLine(0, 0, score.getText().split("\n")[0]+";"+location+";"+points+";"+check4);
            }
            catch(Exception a)
            {
            }
        }
        for(loop1=0; loop1<11; loop1++)
            if(x1==x3[loop1] && y2[loop1]>=(height-175))
            {
                if(loop1!=10)
                    y2[loop1]=-50;
                else
                {
                    y2[loop1]=-10000;
                    check3=1;
                }
                x3[loop1]=pos[(int)(3*Math.random())];
                if(loop1<5)
                    points+=1;
                else
                    points+=2;
                try
                {
                    play("Coins.wav");
                }
                catch(Exception c)
                {
                }
                if(Integer.valueOf(score.getText().split("\n")[1].substring(11))<points)
                    score.setText(score.getText().split("\n")[0] + "\nHighscore: " + points + "\nScore: " + points);
                else
                    score.setText(score.getText().split("\n")[0] + "\n" + score.getText().split("\n")[1] + "\nScore: " + points);
                if(points>=Integer.valueOf(opponent.getText().split("\n")[1].substring(11)) && opponent.isVisible()==true)
                    if(find(points)!=null)
                    {
                        target.setIcon(resize(75, new File(find(points).split(";")[1])));
                        opponent.setText(find(points).split(";")[0].equals(score.getText().split("\n")[0])?"You" + "\nHighscore: " + find(points).split(";")[2]:find(points).split(";")[0] + "\nHighscore: " + find(points).split(";")[2]);
                    }
                    else
                    {
                        target.setVisible(false);
                        opponent.setVisible(false);
                        memoji.setVisible(true);
                    }
                if(points%100==0)
                    moves+=1;
                if(((points/250)%2==0 && check5==0) || check5==1)
                {
                    setBackground(new Color(235, 228, 228));
                    score.setForeground(new Color(0, 0, 0));
                    opponent.setForeground(new Color(0, 0, 0));
                }
                else if(((points/250)%2!=0 && check5==0) || check5==2)
                {
                    setBackground(new Color(0, 0, 0));
                    score.setForeground(new Color(235, 228, 228));
                    opponent.setForeground(new Color(235, 228, 228));
                }
            }
        repaint();
        if(e.getSource()==pause)
        {
            check2=1;
            timer.stop();
            character.setIcon(new ImageIcon("Dead.png"));
            this.add(play);
            this.remove(pause);
        }
        else if(e.getSource()==play)
        {
            check2=0;
            timer.start();
            character.setIcon(new ImageIcon("Character.gif"));
            this.add(pause);
            this.remove(play);
            this.requestFocusInWindow();
        }
        else if(e.getSource()==settings)
        {
            pause.doClick();
            set.setVisible(true);
        }
        else if(e.getSource()==state)
            if(state.isSelected())
            {
                state.setText("Sound OFF");
                check4=1;
            }
            else
            {
                state.setText("Sound ON");
                check4=0;
            }
        else if(e.getSource()==dynamic)
            check5=0;
        else if(e.getSource()==light)
            check5=1;
        else if(e.getSource()==dark)
            check5=2;
        else if(e.getSource()==oval)
            check6=0;
        else if(e.getSource()==rect)
            check6=1;
        else if(e.getSource()==rrect)
            check6=2;
        else if(e.getSource()==restart)
        {
            points=0;
            try
            {
                score.setText(score.getText().split("\n")[0] + "\nHighscore: " + read()[0].split(";")[2] + "\nScore: " + points);
                startGame(1, score.getText().split("\n")[0], location, photo.getIcon());
            }
            catch(Exception a)
            {
            }
        }
    }

    @Override
    public void keyPressed(KeyEvent e)
    {
        int keyCode=e.getKeyCode();
        if(keyCode==KeyEvent.VK_LEFT && (check1==0 || check1==1))
        {
            x1-=(pos[1]-pos[0]);
            check1--;
        }
        else if(keyCode==KeyEvent.VK_RIGHT && (check1==-1 || check1==0))
        {
            x1+=(pos[1]-pos[0]);
            check1++;
        }
        else if(keyCode==KeyEvent.VK_ENTER && restart.isVisible())
            restart.doClick();
        if(check2==0)
            repaint();
    }

    @Override
    public void keyReleased(KeyEvent e)
    {
    }

    @Override
    public void keyTyped(KeyEvent e)
    {
    }

    void startGame(int check, String name, String location, Icon img) throws Exception
    {
        if(check==1)
        {
            JFrame previous=(JFrame)SwingUtilities.getWindowAncestor(this);
            previous.dispose();
        }
        JFrame jf=new JFrame("Infinity Run");
        jf.setExtendedState(JFrame.MAXIMIZED_BOTH);
        jf.setResizable(false);
        jf.setIconImage(Toolkit.getDefaultToolkit().getImage("Logo.jpg"));
        backend panel=new backend(name, location, img);
        panel.setBackground(new Color(235, 228, 228));
        jf.add(panel);
        jf.setVisible(true);
        jf.setDefaultCloseOperation(jf.EXIT_ON_CLOSE);
        if(check==1)
            timer=new Timer(16, this);
        timer.start();
        if(Integer.valueOf(read()[0].split(";")[3])==1)
        {
            check4=1;
            state.setSelected(false);
        }
        play("Start.wav");
    }

    void notif(int x, int y, int width, int height, int time, String message, Color color, JPanel panel) throws Exception
    {
        notification.setText(message);
        notification.setForeground(color);
        notification.setBackground(new Color(255, 255, 255, 0));
        if(panel==null)
            add(notification);
        else
            panel.add(notification);
        notification.setBounds(x, y, width, height);
        if(time!=-1)
        {
            Timer timer=new Timer(time, new ActionListener()
                    {
                        @Override
                        public void actionPerformed(ActionEvent e)
                        {
                            notification.setText("");
                        }
                    });
            timer.setRepeats(false);
            timer.start();
        }
        if(message.contains(" activated"))
        {
            if(message.contains("10"))
                play("Message.wav");
        }
        else
            play("Message.wav");
    }

    void play(String file) throws Exception
    {
        if(check4==0)
        {
            File f=new File(file);
            AudioInputStream ais=AudioSystem.getAudioInputStream(f);
            clip=AudioSystem.getClip();
            clip.open(ais);
            clip.start();
        }
    }

    void writeOnLine(int line, int replace, String text) throws Exception
    {
        if(Integer.valueOf(text.split(";")[2])>0)
        {
            String x[]=read();
            if(replace==1)
            {
                for(int i=x.length-1; i>0; i--)
                    if(i<=line)
                        x[i]=x[i-1];
            }
            else
            {
                x=increase(x);
                for(int i=x.length-1; i>0; i--)
                    x[i]=x[i-1];
            }
            x[0]=text;
            File f, p;
            FileWriter fw;
            BufferedWriter bw;
            for(int i=0, j; i<3; i++)
            {
                f=new File(i==0?"Infinity Run.txt":i==1 ? "D:/Users/Public/Infinity Run.txt" : "D:/Users/Documents/Game/IRun/Infinity Run/Infinity Run.txt");
                p=f.getParentFile();
                if(p!=null && !p.exists())
                    p.mkdirs();
                if(!f.exists())
                    f.createNewFile();
                fw=new FileWriter(f);
                bw=new BufferedWriter(fw);
                for(j=0; j<x.length; j++)
                    if(j+1<x.length)
                        bw.write(x[j] + "\n");
                    else
                        bw.write(x[j]);
                bw.close();
            }
        }
    }

    String[] read() throws Exception
    {
        File file=null;
        if(new File("Infinity Run.txt").exists())
            file=new File("Infinity Run.txt");
        else if(new File("D:/Users/Public/Infinity Run.txt").exists())
            file=new File("D:/Users/Public/Infinity Run.txt");
        else if(new File("D:/Users/Documents/Game/IRun/Infinity Run/Infinity Run.txt").exists())
            file=new File("D:/Users/Documents/Game/IRun/Infinity Run/Infinity Run.txt");
        String text="", x[]=new String[1];
        x[0]="";
        FileReader fr=new FileReader(file);
        BufferedReader br=new BufferedReader(fr);
        while(true)
        {
            text=br.readLine();
            if(text==null)
                break;
            if(x[0]=="")
                x[0]=text;
            else
            {
                x=increase(x);
                x[x.length-1]=text;
            }
        }
        br.close();
        return x;
    }

    String find(int points)
    {
        int i, j;
        String names[]=null;
        try
        {
            names=read();
        }
        catch(Exception e)
        {
        }
        for(i=0, j=0; i<names.length; i++)
            if(Integer.valueOf(names[j].split(";")[2])-points>0)
            {
                if(Integer.valueOf(names[i].split(";")[2])-points<=Integer.valueOf(names[j].split(";")[2])-points && Integer.valueOf(names[i].split(";")[2])-points>0)
                    j=i;
            }
            else if(Integer.valueOf(names[i].split(";")[2])-points>0)
                j=i;
        return Integer.valueOf(names[j].split(";")[2])>points?names[j]:null;
    }

    String readLine(int line)
    {
        try
        {
            return read()[line];
        }
        catch(Exception e)
        {
        }
        return "";
    }

    String[] increase(String array[])
    {
        String x[]=new String[array.length+1];
        for(int i=0; i<array.length; i++)
            x[i]=array[i];
        return x;
    }

    ImageIcon resize(int size, File image)
    {
        BufferedImage img=null;
        try
        {
            img=ImageIO.read(image);
        }
        catch(Exception e)
        {
        }
        int x=img.getWidth(), y=img.getHeight();
        if(x>y)
        {
            y=size*y/x;
            x=size;
        }
        else
        {
            x=size*x/y;
            y=size;
        }
        return (new ImageIcon(img.getScaledInstance(x, y, Image.SCALE_SMOOTH)));
    }
}