import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import javax.swing.*;
import javax.sound.sampled.*;
import javax.imageio.*;
import java.io.*;
class Infinity_Run implements ActionListener, FocusListener, KeyListener
{
    int currentPage, image;
    String location;
    JFrame sets;
    JPanel bg, panel, jp;
    JButton start, user, previous, next, board, imp, help;
    JTextField name;
    JTextArea leaders;
    File images[];
    backend object;
    /*Play Infinity Run, an endless running game.*/
    Infinity_Run()
    {
    }

    @Override
    public void keyReleased(KeyEvent e)
    {
    }

    @Override
    public void keyPressed(KeyEvent e)
    {
        if(e.getKeyCode()==KeyEvent.VK_ENTER)
            start.doClick();
    }

    @Override
    public void keyTyped(KeyEvent e)
    {
    }

    void main()
    {
        sets=new JFrame("Infinity Run - Home");
        sets.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        sets.setIconImage(Toolkit.getDefaultToolkit().getImage("Logo.png"));
        sets.setLayout(null);
        sets.setExtendedState(JFrame.MAXIMIZED_BOTH);
        sets.setResizable(false);
        sets.setVisible(true);
        sets.addKeyListener(this);
        try
        {
            UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
        }
        catch(Exception e)
        {
        }
        name=new JTextField("Enter your name");
        name.addFocusListener(this);
        name.addKeyListener(this);
        board=new JButton("LEADERBOARD");
        board.setFont(new Font("Comic Sans MS", Font.PLAIN, 14));
        board.setBounds(sets.getWidth()-278, 10, 160, 40);
        board.setToolTipText("Leaderboard");
        board.addActionListener(this);
        leaders=new JTextArea("");
        leaders.setToolTipText("Leaders");
        leaders.setFont(new Font("ARIAL", Font.PLAIN, 17));
        leaders.setBackground(new Color(160, 160, 160, 100));
        leaders.setBounds(sets.getWidth()-278, 60, 255, 275);
        leaders.setBorder(BorderFactory.createEmptyBorder());
        leaders.setVisible(false);
        leaders.setForeground(Color.PINK);
        leaders.setFocusable(false);
        help=new JButton("?");
        help.setBounds(sets.getWidth()-61, sets.getHeight()-82, 35, 35);
        help.addActionListener(this);
        help.setToolTipText("Help");
        user=new JButton(new ImageIcon("User.jpg"));
        user.setBounds((sets.getWidth()-130)/2, (sets.getHeight()-130)/4, 130, 130);
        user.setBorder(BorderFactory.createEmptyBorder());
        user.addActionListener(this);
        user.setToolTipText("Profile photo");
        try
        {
            object=new backend("", "User.jpg");
            location=object.names[0].split(";")[1];
        }
        catch(Exception e)
        {
        }
        start=new JButton("START");
        start.setFont(new Font("Comic Sans MS", Font.PLAIN, 14));
        start.setBounds((sets.getWidth()-90)/2, (sets.getHeight()-150), 90, 40);
        image=(int)(11*Math.random()+1);
        imp=new JButton("UPDATE");
        imp.setFont(new Font("Comic Sans MS", Font.PLAIN, 14));
        imp.setBounds(sets.getWidth()-108, 10, 83, 40);
        imp.setToolTipText("Update file");
        imp.addActionListener(this);
        bg=new JPanel()
        {
            @Override
            protected void paintComponent(Graphics g)
            {
                super.paintComponent(g);
                try
                {
                    BufferedImage img=ImageIO.read(new File("Background (" + image + ").jpeg"));
                    g.drawImage(img, 0, 0, getWidth(), getHeight(), this);
                    g.setColor(new Color(255, 0, 0));
                    g.setFont(new Font("Arial", Font.BOLD, 14));
                    g.drawString("ASHIRVAAD VERMA", 12, 24);
                }
                catch(Exception e)
                {
                }
            }
        };
        bg.setLayout(null);
        bg.add(user);
        bg.add(board);
        bg.add(imp);
        bg.add(leaders);
        bg.add(help);
        panel=new JPanel(new GridLayout(3, 3));
        panel.setOpaque(false);
        panel.setBounds(75, 150, 300, 300);
        panel.setVisible(false);
        bg.add(panel);
        previous=new JButton("PREVIOUS");
        previous.setFocusable(false);
        previous.setToolTipText("Previous tray");
        previous.setBounds(75, 500, 101, 40);
        previous.setFont(new Font("Comic Sans MS", Font.PLAIN, 14));
        previous.setVisible(false);
        previous.addActionListener(this);
        bg.add(previous);
        next=new JButton("NEXT");
        next.setFont(new Font("Comic Sans MS", Font.PLAIN, 14));
        next.setFocusable(true);
        next.setBounds(274, 500, 101, 40);
        next.setVisible(false);
        next.addActionListener(this);
        next.setToolTipText("Next tray");
        bg.add(next);
        name.setBounds((sets.getWidth()-300)/2, (sets.getHeight()-40)/2, 300, 40);
        name.setToolTipText(name.getText());
        name.setFont(new Font("Comic Sans MS", Font.BOLD, 20));
        name.setText(object.names[0].split(";")[0]);
        user.setIcon(object.resize(130, new File(object.names[0].split(";")[1])));
        bg.add(name);
        start.setToolTipText("Start game");
        bg.add(start);
        start.addActionListener(this);
        try
        {
            object.notif((sets.getWidth()-453)/2, (sets.getHeight()-30)/2+75, 453, 30, -1, "You can change the name and photo by clicking on them", Color.RED, bg);
        }
        catch(Exception e)
        {
        }
        sets.setContentPane(bg);
        sets.revalidate();
        sets.repaint();
    }

    int check()
    {
        String player=name.getText();
        if(player.length()<1)
            return 0;
        if(player.length()>11)
            return 1;
        for(int i=0; i<player.length(); i++)
            if(Character.isLetter(player.charAt(i))==false)
                return 2;
        return 3;
    }

    @Override
    public void actionPerformed(ActionEvent e)
    {
        if(e.getSource()==start)
            try
            {
                if(check()==3)
                {
                    sets.setVisible(false);
                    object.startGame(0, name.getText(), location);
                }
                else
                {
                    if(check()==0)
                        object.notif(name.getX()+305, name.getY(), 210, 40, 3000, "Enter your name", Color.RED, bg);
                    else if(check()==1)
                        object.notif(name.getX()+305, name.getY(), 210, 40, 3000, "Maximum letter limit is 11", Color.RED, bg);
                    else if(check()==2)
                        object.notif(name.getX()+305, name.getY(), 210, 40, 3000, "Only letters are allowed", Color.RED, bg);
                }
            }
            catch(Exception error)
            {
            }
        else if(e.getSource()==user)
        {
            JFileChooser directory=new JFileChooser();
            directory.setCurrentDirectory(new File("Avatars"));
            directory.setApproveButtonText("Select");
            directory.setDialogTitle("Choose your profile picture");
            directory.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
            if(directory.showOpenDialog(null)==JFileChooser.APPROVE_OPTION)
            {
                File files[]=directory.getSelectedFile().listFiles();
                images=filter(files);
                currentPage=0;
                display(currentPage);
            }
        }
        else if(e.getSource()==next && (currentPage+1)*9<images.length)
            display(++currentPage);
        else if(e.getSource()==previous && currentPage>0)
            display(--currentPage);
        else if(e.getSource()==board)
            if(leaders.isVisible())
            {
                leaders.setVisible(false);
                jp.setVisible(false);
            }
            else
            {
                String player, names[]=null;
                names=object.names;
                for(int i=0, j, temp; i<10 && i<names.length; i++)
                {
                    for(j=i, temp=i; j<names.length; j++)
                        if(Integer.valueOf(names[temp].split(";")[2])<Integer.valueOf(names[j].split(";")[2]))
                            temp=j;
                    player=names[i];
                    names[i]=names[temp];
                    names[temp]=player;
                }
                leaders.setText("");
                for(int i=0; i<names.length; i++)
                    if(i<10)
                        leaders.setText(leaders.getText() + "\n  " + (i+1) + "\t" + names[i].split(";")[0] + "\t" + names[i].split(";")[2]);
                    else if(names[i].split(";")[0].equals(name.getText()))
                        leaders.setText(leaders.getText() + "\n  " + (i+1) + "\t" + names[i].split(";")[0] + "\t" + names[i].split(";")[2]);
                jp=new JPanel();
                jp.setLayout(new BoxLayout(jp, BoxLayout.Y_AXIS));
                jp.setOpaque(false);
                for(int i=0; i<names.length; i++)
                {
                    JLabel jl=new JLabel();
                    if(i<10)
                        jl.setIcon(object.resize(21, new File(names[i].split(";")[1])));
                    else if(names[i].split(";")[0].equals(name.getText()))
                        jl.setIcon(object.resize(21, new File(names[i].split(";")[1])));
                    jp.add(jl);
                }
                jp.setVisible(true);
                jp.setBounds(sets.getWidth()-297, 80, 75, 275);
                bg.add(jp);
                leaders.setVisible(true);
            }
        else if(e.getSource()==imp)
        {
            try
            {
                String text, names2[]=new String[1];
                names2[0]="";
                File file=null;
                if(new File("D:/Users/Documents/Game/IRun/Infinity Run/Infinity Run.txt").exists())
                    file=new File("D:/Users/Documents/Game/IRun/Infinity Run/Infinity Run.txt");
                else if(new File("D:/Users/Public/Infinity Run.txt").exists())
                    file=new File("D:/Users/Public/Infinity Run.txt");
                else if(new File("C:/Users/Public/Infinity Run.txt").exists())
                    file=new File("C:/Users/Public/Infinity Run.txt");
                else if(new File("C:/Intel/Infinity Run.txt").exists())
                    file=new File("C:/Intel/Infinity Run.txt");
                FileReader fr=new FileReader(file);
                BufferedReader br=new BufferedReader(fr);
                while(true)
                {
                    text=br.readLine();
                    if(text==null)
                        break;
                    if(names2[0]=="")
                        names2[0]=text;
                    else
                    {
                        names2=object.increase(names2);
                        names2[names2.length-1]=text;
                    }
                }
                br.close();
                String names3[]=object.names;
                for(int i=0, j; i<names2.length; i++)
                {
                    for(j=0; j<names3.length; j++)
                        if(names3[j].split(";")[0].equals(names2[i].split(";")[0]))
                        {
                            names3[j]=Integer.valueOf(names3[j].split(";")[2])>Integer.valueOf(names2[i].split(";")[2])?names3[j]:names2[i];
                            j=names3.length+1;
                        }
                    if(j==names3.length)
                    {
                        names3=object.increase(names3);
                        names3[names3.length-1]=names2[i];
                    }
                }
                File f=new File("Infinity Run.txt");
                FileWriter fw=new FileWriter(f);
                BufferedWriter bw=new BufferedWriter(fw);
                for(int i=0; i<names3.length; i++)
                    bw.write(names3[i]+"\n");
                bw.close();
                object.notif((sets.getWidth()-210)/2, (sets.getHeight()-210)/4, 210, 25, 3000, "File updated successfully", Color.PINK, bg);
            }
            catch(Exception d)
            {
            }
        }
        else if(e.getSource()==help)
        {
            String s="";
            File f;
            FileReader fr;
            BufferedReader br=null;
            try
            {
                f=new File("README.txt");
                fr=new FileReader(f);
                br=new BufferedReader(fr);
                for(int i=0; i<20; i++)
                    s+=br.readLine()+"\n";
                br.close();
            }
            catch(Exception a)
            {
            }
            JOptionPane.showMessageDialog(null, s, "Help", JOptionPane.INFORMATION_MESSAGE, object.resize(75, new File("Logo.png")));
        }
    }

    @Override
    public void focusGained(FocusEvent e)
    {
        if(e.getSource()==name)
            name.setText("");
    }

    @Override
    public void focusLost(FocusEvent e)
    {
    }

    File[] filter(File files[])
    {
        int count=0;
        if(files==null)
            return new File[0];
        for(int i=0; i<files.length; i++)
        {
            String filename=files[i].getName().toLowerCase();
            if(filename.endsWith(".jpg") || filename.endsWith(".png") || filename.endsWith(".gif") || filename.endsWith(".bmp") || filename.endsWith(".jpeg"))
                count++;
        }
        File images[]=new File[count];
        for(int i=0, index=0; i<files.length; i++)
        {
            String filename=files[i].getName().toLowerCase();
            if(filename.endsWith(".jpg") || filename.endsWith(".png") || filename.endsWith(".gif") || filename.endsWith(".bmp") || filename.endsWith(".jpeg"))
                images[index++]=files[i];
        }
        return images;
    }

    void display(int page)
    {
        int start=page*9, end=Math.min(start+9, images.length);
        panel.removeAll();
        for(int i=start; i<end; i++)
            try
            {
                panel.setVisible(true);
                JLabel imageLabel=new JLabel();
                imageLabel.setIcon(object.resize(100, images[i]));
                panel.add(imageLabel);
                final BufferedImage finalImg=ImageIO.read(images[i]);
                final int index=i;
                imageLabel.addMouseListener(new MouseAdapter()
                    {
                        @Override
                        public void mouseClicked(MouseEvent e)
                        {
                            Image scaledImage=finalImg.getScaledInstance(user.getWidth(), user.getHeight(), Image.SCALE_SMOOTH);
                            user.setIcon(new ImageIcon(scaledImage));
                            panel.setVisible(false);
                            previous.setVisible(false);
                            next.setVisible(false);
                            location=images[index].getPath();
                        }
                    });
            }
            catch(Exception error)
            {
            }
        next.setVisible(end<images.length);
        previous.setVisible(start>0);
        sets.revalidate();
        sets.repaint();
    }
}
class backend extends JPanel implements ActionListener, KeyListener, ComponentListener, MouseListener
{
    int loop1, x1, check1, x2[]=new int[2], y1[]=new int[2], x3[]=new int[11], pos[]=new int[3], check2, y2[]=new int[11], points, moves=15, height=420, width=420, x, y, check3, y3[]=new int[4];
    String location, names[]=new String[1];
    JTextField notification;
    JTextArea score, opponent;
    JFrame set;
    JButton play, pause, settings, photo, restart, target;
    JToggleButton state;
    JRadioButton themes[]=new JRadioButton[3];
    ButtonGroup theme;
    JLabel character, memoji, barrier1, barrier2, coin[]=new JLabel[11];
    Clip clip;
    Timer timer;
    backend(String name, String location) throws Exception
    {
        character=new JLabel(new ImageIcon("Dead.png"));
        barrier1=new JLabel(new ImageIcon("Fire.gif"));
        barrier2=new JLabel(new ImageIcon("Fire.gif"));
        for(int i=0; i<5; i++)
            coin[i]=new JLabel(new ImageIcon("Coin (1).gif"));
        for(int i=5; i<10; i++)
            coin[i]=new JLabel(new ImageIcon("Coin (2).gif"));
        coin[10]=new JLabel(new ImageIcon("Spell.gif"));
        play=new JButton(new ImageIcon("Resume.jpeg"));
        pause=new JButton(new ImageIcon("Pause.jpeg"));
        settings=new JButton(new ImageIcon("Settings.jpeg"));
        timer=new Timer(16, this);
        timer.start();
        setFocusable(true);
        addKeyListener(this);
        addMouseListener(this);
        y1[1]=(int)(101*Math.random()-250);
        state=new JToggleButton();
        themes[0]=new JRadioButton("Dynamic theme");
        themes[1]=new JRadioButton("Light theme");
        themes[2]=new JRadioButton("Dark theme");
        File file=null;
        if(new File("D:/Users/Documents/Game/IRun/Infinity Run/Infinity Run.txt").exists())
            file=new File("D:/Users/Documents/Game/IRun/Infinity Run/Infinity Run.txt");
        else if(new File("D:/Users/Public/Infinity Run.txt").exists())
            file=new File("D:/Users/Public/Infinity Run.txt");
        else if(new File("C:/Users/Public/Infinity Run.txt").exists())
            file=new File("C:/Users/Public/Infinity Run.txt");
        else if(new File("C:/Intel/Infinity Run.txt").exists())
            file=new File("C:/Intel/Infinity Run.txt");
        else if(new File("Infinity Run.txt").exists())
            file=new File("Infinity Run.txt");
        String text="", text1;
        names[0]="";
        FileReader fr=new FileReader(file);
        BufferedReader br=new BufferedReader(fr);
        while(true)
        {
            text=br.readLine();
            if(text==null)
                break;
            text1="";
            for(int i=0; i<text.length(); i++)
                text1+=(char)(text.charAt(i)/2);
            if(names[0]=="")
                names[0]=text1;
            else
            {
                names=increase(names);
                names[names.length-1]=text1;
            }
        }
        br.close();
        for(int i=-1; i<names.length; i++)
            if(i==names.length-1)
            {
                score=new JTextArea(name + "\nHigh score: 0\nscore: " + points);
                state.setText("Sound ON");
                themes[0].setSelected(true);
                break;
            }
            else if(names[i+1].split(";")[0].equals(name))
            {
                score=new JTextArea(name + "\nHigh score: " + names[i+1].split(";")[2] + "\nScore: " + points);
                if(Integer.valueOf(names[i+1].split(";")[4])==1)
                    state.setText("Sound ON");
                else
                    state.setText("Sound OFF");
                themes[Integer.valueOf(names[i+1].split(";")[3])].setSelected(true);
                break;
            }
        score.setToolTipText("Scoreboard");
        score.setFocusable(false);
        score.setFont(new Font("Kristen ITC", Font.BOLD, 17));
        score.setBackground(new Color(255, 255, 255, 0));
        score.setBorder(BorderFactory.createEmptyBorder());
        play.setToolTipText("Resume game");
        play.addKeyListener(this);
        pause.addKeyListener(this);
        pause.setToolTipText("Pause game");
        settings.setToolTipText("Open settings");
        play.setBounds(5, 5, 50, 50);
        this.add(play);
        pause.setBounds(5, 5, 50, 50);
        this.add(pause);
        settings.setBounds(55, 5, 50, 50);
        pause.addActionListener(this);
        play.addActionListener(this);
        settings.addActionListener(this);
        addComponentListener(this);
        this.setLayout(null);
        this.add(score);
        this.add(settings);
        this.add(character);
        this.add(barrier1);
        this.add(barrier2);
        for(int i=0; i<11; i++)
            this.add(coin[i]);
        set=new JFrame("Infinity Run - Settings");
        set.setLayout(null);
        set.setSize(420, 420);
        set.setResizable(false);
        set.setIconImage(Toolkit.getDefaultToolkit().getImage("Logo.png"));
        state.setBounds((set.getWidth()-100)/2, (set.getHeight()-60)/2+50, 100, 30);
        state.addActionListener(this);
        set.add(state);
        themes[0].setBounds((set.getWidth()-330)/4, (set.getHeight()-60)/2-50, 110, 30);
        themes[1].setBounds((set.getWidth()-330)/2+100, (set.getHeight()-60)/2-50, 110, 30);
        themes[2].setBounds(3*(set.getWidth()-330)/4+200, (set.getHeight()-60)/2-50, 110, 30);
        theme=new ButtonGroup();
        theme.add(themes[0]);
        theme.add(themes[1]);
        theme.add(themes[2]);
        set.add(themes[0]);
        set.add(themes[1]);
        set.add(themes[2]);
        photo=new JButton();
        photo.setIcon(resize(75, new File(location)));
        photo.setBackground(new Color(255, 255, 255, 0));
        photo.setBorder(BorderFactory.createEmptyBorder());
        add(photo);
        memoji=new JLabel();
        if(score.getText().split("\n")[0].endsWith("a") || score.getText().split("\n")[0].endsWith("e") || score.getText().split("\n")[0].endsWith("i") || score.getText().split("\n")[0].endsWith("m") || score.getText().split("\n")[0].endsWith("o") || score.getText().split("\n")[0].endsWith("u"))
            memoji.setIcon(resize(100, new File("Victory (1).png")));
        else
            memoji.setIcon(resize(100, new File("Victory (2).png")));
        memoji.setBorder(BorderFactory.createEmptyBorder());
        memoji.setOpaque(false);
        add(memoji);
        restart=new JButton("RESTART");
        restart.setFont(new Font("Comic Sans MS", Font.BOLD, 14));
        add(restart);
        restart.setVisible(false);
        restart.setToolTipText("Restart game");
        restart.addActionListener(this);
        restart.addKeyListener(this);
        opponent=new JTextArea(find(points).split(";")[0].equals(score.getText().split("\n")[0])?"You" + "\nHigh score: " + find(points).split(";")[2]:find(points).split(";")[0] + "\nHigh score: " + find(points).split(";")[2]);
        opponent.setBackground(new Color(255, 255, 255, 0));
        opponent.setFocusable(false);
        opponent.setFont(new Font("Kristen ITC", Font.BOLD, 17));
        opponent.setToolTipText("Target");
        opponent.setBorder(BorderFactory.createEmptyBorder());
        add(opponent);
        this.location=location;
        target=new JButton();
        target.setIcon(resize(75, new File(find(0).split(";")[1])));
        target.setBackground(new Color(255, 255, 255, 0));
        target.setBorder(BorderFactory.createEmptyBorder());
        add(target);
        notification=new JTextField();
        notification.setHorizontalAlignment(JTextField.CENTER);
        notification.setBorder(BorderFactory.createEmptyBorder());
        notification.setFont(new Font("Bahnschrift", Font.BOLD, 17));
        notification.setOpaque(false);
    }

    @Override
    protected void paintComponent(Graphics g)
    {
        super.paintComponent(g);
        Graphics2D g2d=(Graphics2D)g;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2d.setStroke(new BasicStroke(5));
        g.setColor(new Color(42, 48, 43));
        g2d.drawLine(x, 0, 10, height);
        g2d.drawLine(x+70, 0, y+20, height);
        g2d.drawLine(x*3+80, 0, y+40, height);
        g2d.drawLine(x*3+150, 0, y*2+50, height);
        g2d.drawLine(x*5+160, 0, y*2+70, height);
        g2d.drawLine(x*5+230, 0, y*3+80, height);
        if(getBackground().equals(new Color(235, 228, 228)))
            g.setColor(new Color(255, 255, 255));
        else
            g.setColor(new Color(130, 125, 120));
        for(loop1=0; loop1<4; loop1++)
        {
            g.fillRect(pos[0]+17, y3[loop1], 15, height/7);
            g.fillRect(pos[1]+17, y3[loop1], 15, height/7);
            g.fillRect(pos[2]+17, y3[loop1], 15, height/7);
        }
    }

    @Override
    public void componentResized(ComponentEvent e)
    {
        setTheme();
        height=getHeight();
        width=getWidth();
        x=(width-240)/6;
        y=(width-100)/3;
        pos[0]=x+15;
        pos[1]=pos[0]+80+x*2;
        pos[2]=2*pos[1]-pos[0];
        x1=pos[1];
        for(loop1=0; loop1<2; loop1++)
            x2[loop1]=pos[(int)(3*Math.random())];
        for(loop1=0; loop1<11; loop1++)
            x3[loop1]=pos[(int)(3*Math.random())];
        y3[0]=0;
        y3[1]=2*height/7;
        y3[2]=4*height/7;
        y3[3]=6*height/7;
        repaint();
        score.setBounds(width-136, 85, 131, 70);
        restart.setBounds((width-101)/2, (height-40)/4, 101, 40);
        photo.setBounds(width-108, 5, 75, 75);
        target.setBounds(width-108, 165, 75, 75);
        opponent.setBounds(width-136, 245, 131, 44);
        memoji.setBounds(width-120, 165, 100, 100);
        memoji.setVisible(false);
        if(points==0)
        {
            pause.doClick();
            try
            {
                notif((width-210)/2, (height-210)/4, 210, 25, 3000, "3", Color.RED, null);
            }
            catch(Exception a)
            {
            }
            Timer countdown2=new Timer(1000, new ActionListener()
                    {
                        @Override
                        public void actionPerformed(ActionEvent e)
                        {
                            try
                            {
                                notif((width-210)/2, (height-210)/4, 210, 25, 3000, "2", Color.ORANGE, null);
                            }
                            catch(Exception b)
                            {
                            }
                        }
                    });
            countdown2.setRepeats(false);
            countdown2.start();
            Timer countdown1=new Timer(2000, new ActionListener()
                    {
                        @Override
                        public void actionPerformed(ActionEvent e)
                        {
                            try
                            {
                                notif((width-210)/2, (height-210)/4, 210, 25, 3000, "1", Color.YELLOW, null);
                            }
                            catch(Exception b)
                            {
                            }
                        }
                    });
            countdown1.setRepeats(false);
            countdown1.start();
            Timer countdown0=new Timer(3000, new ActionListener()
                    {
                        @Override
                        public void actionPerformed(ActionEvent e)
                        {
                            try
                            {
                                notif((width-210)/2, (height-210)/4, 210, 25, 1500, "RUN!", Color.GREEN, null);
                                play.doClick();
                            }
                            catch(Exception b)
                            {
                            }
                        }
                    });
            countdown0.setRepeats(false);
            countdown0.start();
        }
    }

    void setTheme()
    {
        if(((points/250)%2==0 && themes[0].isSelected()) || themes[1].isSelected())
        {
            setBackground(new Color(235, 228, 228));
            score.setForeground(new Color(0, 0, 0));
            opponent.setForeground(new Color(0, 0, 0));
        }
        else if(((points/250)%2!=0 && themes[0].isSelected()) || themes[2].isSelected())
        {
            setBackground(new Color(0, 0, 0));
            score.setForeground(new Color(235, 228, 228));
            opponent.setForeground(new Color(235, 228, 228));
        }
    }

    @Override
    public void componentHidden(ComponentEvent e)
    {
    }

    @Override
    public void componentShown(ComponentEvent e)
    {
    }

    @Override
    public void componentMoved(ComponentEvent e)
    {
    }

    @Override
    public void mouseExited(MouseEvent e)
    {
    }

    @Override
    public void mouseEntered(MouseEvent e)
    {
    }

    @Override
    public void mouseReleased(MouseEvent e)
    {
    }

    @Override
    public void mousePressed(MouseEvent e)
    {
        if(e.getButton()==MouseEvent.BUTTON1 && (check1==0 || check1==1) && pause.isVisible())
        {
            x1-=(pos[1]-pos[0]);
            check1--;
        }
        else if(e.getButton()==MouseEvent.BUTTON3 && (check1==-1 || check1==0) && pause.isVisible())
        {
            x1+=(pos[1]-pos[0]);
            check1++;
        }
    }

    @Override
    public void mouseClicked(MouseEvent e)
    {
    }

    @Override
    public void actionPerformed(ActionEvent e)
    {
        if(e.getSource()!=themes[0] && e.getSource()!=themes[1] && e.getSource()!=themes[2] && e.getSource()!=settings && e.getSource()!=state && e.getSource()!=pause)
        {
            for(loop1=0; loop1<2; loop1++)
                y1[loop1]+=moves;
            for(loop1=0; loop1<11; loop1++)
                y2[loop1]+=moves;
            for(loop1=0; loop1<4; loop1++)
                y3[loop1]+=moves;
        }
        try
        {
            if(y2[10]<-9000 && y2[10]>=-10000 && check3==1 && notification.getText().equals("Special ability activated (5)")==false)
                notif((width-210)/2, (height-210)/4, 220, 25, -1, "Special ability activated (5)", new Color(0, 255, 0), null);
            else if(y2[10]<-8000 && y2[10]>=-9000 && check3==1 && notification.getText().equals("Special ability activated (4)")==false)
                notif((width-210)/2, (height-210)/4, 220, 25, -1, "Special ability activated (4)", new Color(255, 255, 0), null);
            else if(y2[10]<-7000 && y2[10]>=-8000 && check3==1 && notification.getText().equals("Special ability activated (3)")==false)
                notif((width-210)/2, (height-210)/4, 220, 25, -1, "Special ability activated (3)", new Color(255, 153, 0), null);
            else if(y2[10]<-6000 && y2[10]>=-7000 && check3==1 && notification.getText().equals("Special ability activated (2)")==false)
                notif((width-210)/2, (height-210)/4, 220, 25, -1, "Special ability activated (2)", new Color(255, 51, 0), null);
            else if(y2[10]<-5000 && y2[10]>=-6000 && check3==1 && notification.getText().equals("Special ability activated (1)")==false)
                notif((width-210)/2, (height-210)/4, 220, 25, -1, "Special ability activated (1)", new Color(204, 0, 0), null);
        }
        catch(Exception b)
        {
        }
        character.setBounds(x1-6, height-150, 61, 150);
        barrier1.setBounds(x2[0], y1[0], 60, 79);
        for(; x2[0]==x2[1] && y1[0]==y1[1]; )
            x2[1]=x2[0]=pos[(int)(3*Math.random())];
        barrier2.setBounds(x2[1], y1[1], 60, 79);
        for(loop1=0; loop1<10; loop1++)
            coin[loop1].setBounds(x3[loop1]+8, y2[loop1], 30, 30);
        coin[10].setBounds(x3[loop1], y2[loop1], 60, 65);
        if(y1[0]>height)
        {
            y1[0]=-50;
            x2[0]=pos[(int)(3*Math.random())];
        }
        else if(y1[1]>height)
        {
            y1[1]=(int)(101*Math.random()-250);
            x2[1]=pos[(int)(3*Math.random())];
        }
        for(loop1=0; loop1<10; loop1++)
            if(y2[loop1]>height)
            {
                y2[loop1]=-50;
                x3[loop1]=pos[(int)(3*Math.random())];
            }
        if(y2[10]>height)
        {
            y2[10]=-10000;
            x3[10]=pos[(int)(3*Math.random())];
        }
        for(loop1=0; loop1<4; loop1++)
            if(y3[loop1]>height)
                y3[loop1]=-height/7;
        if(y2[10]>-5000 && check3==1)
        {
            check3=0;
            try
            {
                notif((width-210)/2, (height-210)/4, 220, 25, 3000, "Special ability deactivated", Color.RED, null);
            }
            catch(Exception b)
            {
            }
        }
        if(((x1==x2[0] && y1[0]>=(height-230)) || (x1==x2[1] && y1[1]>=(height-230))) && (check3==0 || y2[10]>-7000))
        {
            check2=1;
            timer.stop();
            play.setEnabled(false);
            pause.setEnabled(false);
            settings.setEnabled(false);
            try
            {
                play("End.wav");
                notif((width-210)/2, (height-210)/4, 210, 25, -1, "GAME OVER", Color.RED, null);
                character.setIcon(new ImageIcon("Dead.png"));
                if(score.getText().split("\n")[0].endsWith("a") || score.getText().split("\n")[0].endsWith("e") || score.getText().split("\n")[0].endsWith("i") || score.getText().split("\n")[0].endsWith("m") || score.getText().split("\n")[0].endsWith("o") || score.getText().split("\n")[0].endsWith("u"))
                    memoji.setIcon(resize(100, new File("Shocked (1).png")));
                else
                    memoji.setIcon(resize(100, new File("Shocked (2).png")));
                opponent.setVisible(false);
                target.setVisible(false);
                memoji.setVisible(true);
                restart.setVisible(true);
                int i=0, check=0;
                for(; i<names.length; i++)
                    if(names[i].split(";")[0].equals(score.getText().split("\n")[0]))
                    {
                        if(Integer.valueOf(names[i].split(";")[2])<points)
                            writeOnLine(i, 1, score.getText().split("\n")[0]+";"+location+";"+points+";"+(themes[0].isSelected()?0:themes[1].isSelected()?1:2)+";"+(state.getText().equals("Sound ON")?1:0));
                        else
                            writeOnLine(i, 1, score.getText().split("\n")[0]+";"+location+";"+names[i].split(";")[2]+";"+(themes[0].isSelected()?0:themes[1].isSelected()?1:2)+";"+(state.getText().equals("Sound ON")?1:0));
                        check=1;
                    }
                if(check==0)
                    writeOnLine(0, 0, score.getText().split("\n")[0]+";"+location+";"+points+";"+(themes[0].isSelected()?0:themes[1].isSelected()?1:2)+";"+(state.getText().equals("Sound ON")?1:0));
            }
            catch(Exception a)
            {
            }
        }
        if(x1==x3[10] && y2[10]>=(height-215))
        {
            y2[10]=-10000;
            check3=1;
            x3[10]=pos[(int)(3*Math.random())];
        }
        else
            for(loop1=0; loop1<10; loop1++)
                if(x1==x3[loop1] && y2[loop1]>=(height-180))
                {
                    y2[loop1]=-50;
                    x3[loop1]=pos[(int)(3*Math.random())];
                    if(loop1<5)
                        points+=1;
                    else
                        points+=2;
                    try
                    {
                        play("Coins.wav");
                    }
                    catch(Exception c)
                    {
                    }
                    if(Integer.valueOf(score.getText().split("\n")[1].substring(12))<points)
                        score.setText(score.getText().split("\n")[0] + "\nHigh score: " + points + "\nScore: " + points);
                    else
                        score.setText(score.getText().split("\n")[0] + "\n" + score.getText().split("\n")[1] + "\nScore: " + points);
                    if(points>=Integer.valueOf(opponent.getText().split("\n")[1].substring(12)) && opponent.isVisible()==true)
                        if(find(points)!=null)
                        {
                            try
                            {
                                notif((width-308)/2, (height-210)/4, 308, 25, 3000, "You broke " + (opponent.getText().split("\n")[0].equals("You")?"your high score":opponent.getText().split("\n")[0] + "'s high score"), Color.GREEN, null);
                            }
                            catch(Exception a)
                            {
                            }
                            target.setIcon(resize(75, new File(find(points).split(";")[1])));
                            opponent.setText(find(points).split(";")[0].equals(score.getText().split("\n")[0])?"You" + "\nHigh score: " + find(points).split(";")[2]:find(points).split(";")[0] + "\nHigh score: " + find(points).split(";")[2]);
                        }
                        else
                        {
                            try
                            {
                                notif((width-232)/2, (height-210)/4, 232, 25, 3000, "You broke all high scores", Color.GREEN, null);
                            }
                            catch(Exception a)
                            {
                            }
                            target.setVisible(false);
                            opponent.setVisible(false);
                            memoji.setVisible(true);
                        }
                    if(points%100==0)
                        moves+=1;
                    setTheme();
                }
        repaint();
        if(e.getSource()==pause)
        {
            check2=1;
            timer.stop();
            character.setIcon(new ImageIcon("Dead.png"));
            play.setVisible(true);
            pause.setVisible(false);
        }
        else if(e.getSource()==play)
        {
            setTheme();
            check2=0;
            timer.start();
            character.setIcon(new ImageIcon("Character.gif"));
            play.setVisible(false);
            pause.setVisible(true);
            this.requestFocusInWindow();
        }
        else if(e.getSource()==settings)
        {
            pause.doClick();
            set.setVisible(true);
        }
        else if(e.getSource()==state)
            if(state.getText().equals("Sound ON"))
                state.setText("Sound OFF");
            else
                state.setText("Sound ON");
        else if(e.getSource()==restart)
        {
            points=0;
            try
            {
                score.setText(score.getText().split("\n")[0] + "\nHigh score: " + names[0].split(";")[2] + "\nScore: " + points);
                startGame(1, score.getText().split("\n")[0], location);
            }
            catch(Exception a)
            {
            }
        }
    }

    @Override
    public void keyPressed(KeyEvent e)
    {
        int keyCode=e.getKeyCode();
        if(keyCode==KeyEvent.VK_LEFT && (check1==0 || check1==1) && pause.isVisible() && check2!=1)
        {
            x1-=(pos[1]-pos[0]);
            check1--;
        }
        else if(keyCode==KeyEvent.VK_RIGHT && (check1==-1 || check1==0) && pause.isVisible() && check2!=1)
        {
            x1+=(pos[1]-pos[0]);
            check1++;
        }
        else if(keyCode==KeyEvent.VK_SPACE)
        {
            if(pause.isVisible())
                pause.doClick();
            else if(notification.getText().equals("1")==false && notification.getText().equals("2")==false && notification.getText().equals("3")==false && notification.getText().equals("RUN!")==false)
                play.doClick();
        }
        else if(keyCode==KeyEvent.VK_S)
            settings.doClick();
        else if(keyCode==KeyEvent.VK_ENTER && restart.isVisible())
            restart.doClick();
        if(check2==0)
            repaint();
    }

    @Override
    public void keyReleased(KeyEvent e)
    {
    }

    @Override
    public void keyTyped(KeyEvent e)
    {
    }

    void startGame(int check, String name, String location) throws Exception
    {
        if(check==1)
        {
            JFrame previous=(JFrame)SwingUtilities.getWindowAncestor(this);
            previous.dispose();
        }
        JFrame jf=new JFrame("Infinity Run");
        jf.setExtendedState(JFrame.MAXIMIZED_BOTH);
        jf.setResizable(false);
        jf.setIconImage(Toolkit.getDefaultToolkit().getImage("Logo.png"));
        backend panel=new backend(name, location);
        panel.setBackground(new Color(235, 228, 228));
        jf.add(panel);
        jf.setVisible(true);
        jf.setDefaultCloseOperation(jf.EXIT_ON_CLOSE);
        if(check==1)
            timer=new Timer(16, this);
        timer.start();
        play("Start.wav");
    }

    void notif(int x, int y, int width, int height, int time, String message, Color color, JPanel panel) throws Exception
    {
        notification.setText(message);
        notification.setForeground(color);
        notification.setBackground(new Color(255, 255, 255, 0));
        if(panel==null)
            add(notification);
        else
            panel.add(notification);
        notification.setBounds(x, y, width, height);
        if(time!=-1)
        {
            Timer timer=new Timer(time, new ActionListener()
                    {
                        @Override
                        public void actionPerformed(ActionEvent e)
                        {
                            notification.setText("");
                        }
                    });
            timer.setRepeats(false);
            timer.start();
        }
        if(message.contains(" activated"))
        {
            if(message.contains("10"))
                play("Message.wav");
        }
        else
            play("Message.wav");
    }

    void play(String file) throws Exception
    {
        if(state.getText().equals("Sound ON"))
        {
            File f=new File(file);
            AudioInputStream ais=AudioSystem.getAudioInputStream(f);
            clip=AudioSystem.getClip();
            clip.open(ais);
            clip.start();
        }
    }

    void writeOnLine(int line, int replace, String text) throws Exception
    {
        if(Integer.valueOf(text.split(";")[2])>0)
        {
            String x[]=names;
            if(replace==1)
            {
                for(int i=x.length-1; i>0; i--)
                    if(i<=line)
                        x[i]=x[i-1];
            }
            else
            {
                x=increase(x);
                for(int i=x.length-1; i>0; i--)
                    x[i]=x[i-1];
            }
            x[0]=text;
            File f, p;
            FileWriter fw;
            BufferedWriter bw;
            for(int i=0, j, k; i<5; i++)
            {
                f=new File(i==0?"Infinity Run.txt":i==1 ? "C:/Intel/Infinity Run.txt":i==2 ? "C:/Users/Public/Infinity Run.txt":i==3 ? "D:/Users/Public/Infinity Run.txt":"D:/Users/Documents/Game/IRun/Infinity Run/Infinity Run.txt");
                p=f.getParentFile();
                if(p!=null && !p.exists())
                    p.mkdirs();
                if(!f.exists())
                    f.createNewFile();
                fw=new FileWriter(f);
                bw=new BufferedWriter(fw);
                for(j=0; j<x.length; j++)
                {
                    for(k=0, text=""; k<x[j].length(); k++)
                        text+=(char)(x[j].charAt(k)*2);
                    if(j+1<x.length)
                        bw.write(text + "\n");
                    else
                        bw.write(text);
                }
                bw.close();
            }
        }
    }

    String find(int points)
    {
        int i, j;
        for(i=0, j=0; i<names.length; i++)
            if(Integer.valueOf(names[j].split(";")[2])-points>0)
            {
                if(Integer.valueOf(names[i].split(";")[2])-points<=Integer.valueOf(names[j].split(";")[2])-points && Integer.valueOf(names[i].split(";")[2])-points>0)
                    j=i;
            }
            else if(Integer.valueOf(names[i].split(";")[2])-points>0)
                j=i;
        return Integer.valueOf(names[j].split(";")[2])>points?names[j]:null;
    }

    String[] increase(String array[])
    {
        String x[]=new String[array.length+1];
        for(int i=0; i<array.length; i++)
            x[i]=array[i];
        return x;
    }

    ImageIcon resize(int size, File image)
    {
        BufferedImage img=null;
        try
        {
            img=ImageIO.read(image);
        }
        catch(Exception e)
        {
        }
        int x=img.getWidth(), y=img.getHeight();
        if(x>y)
        {
            y=size*y/x;
            x=size;
        }
        else
        {
            x=size*x/y;
            y=size;
        }
        return (new ImageIcon(img.getScaledInstance(x, y, Image.SCALE_SMOOTH)));
    }
}